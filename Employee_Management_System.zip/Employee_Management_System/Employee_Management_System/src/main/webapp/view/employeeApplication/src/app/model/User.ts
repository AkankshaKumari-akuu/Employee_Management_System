
export class User {

    userid: String = '';
    first: String = '';
    last: String = '';
    email: String = '';
    phone: Number = 0;
    password: String = '';
    address: String = '';

}
